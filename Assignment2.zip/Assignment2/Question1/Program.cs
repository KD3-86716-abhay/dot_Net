﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    public class Program
    {

        public struct Student
        {
            //private String name;
            //private Boolean gender;
            //private int age;
            //private int std;
            //private char div;
            //private double marks;
            #region getter setter and fields

            private String _name;

            public String name
            {
                get { return _name; }
                set { _name = value; }
            }

            private Boolean _gender;

            public Boolean gender
            {
                get { return _gender; }
                set { _gender = value; }
            }

            private int _age;

            public int age
            {
                get { return _age; }
                set { _age = value; }
            }

            private int _std;

            public int std
            {
                get { return _std; }
                set { _std = value; }
            }

            private char _div;

            public char div
            {
                get { return _div; }
                set { _div = value; }
            }

            private Double _marks;

            public Double marks
            {
                get { return _marks; }
                set { _marks = value; }
            }


            #endregion

            //public Student()
            //{
            //    _name = "abhay";
            //    _gender = true;
            //    _age = 22;
            //    _std = 15;
            //    _div = 'A';
            //    _marks = 60.55;
            //}



            public Student(String name, Boolean gender, int age, int std, char div, Double marks)
            {
                _name = name;
                _gender = gender;
                _age = age;
                _std = std;
                _div = div;
                _marks = marks;
            }

            public void AcceptDetails()
            {
                Console.WriteLine("enter name");
                name=Console.ReadLine();

                Console.WriteLine("enter gender");
                gender = Convert.ToBoolean(int.Parse(Console.ReadLine()));

                Console.WriteLine("enter age");
                int age = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter std");
                int std = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter div");
                char div =Convert.ToChar(Console.ReadLine());

                Console.WriteLine("enter marks");
                double marks=Convert.ToDouble(Console.ReadLine());
            }

            public void PrintDetails()
            {
                Console.WriteLine(name.ToString() + " " + gender.ToString() + "" + age.ToString() + "" + std.ToString() + "" + div.ToString() + "" + marks.ToString());
            }



            static void Main(string[] args)
            {
                Student[] studentsArray;

                CreateArray(out studentsArray);
                AcceptInfo(studentsArray);
                
                Console.WriteLine("\nOriginal Student Array:");
                PrintInfo(studentsArray);

                
                Student[] reversedArray = new Student[studentsArray.Length];
                ReverseArray(studentsArray, reversedArray);

                
                Console.WriteLine("\nReversed Student Array:");
                PrintInfo(reversedArray);

                Console.ReadLine();

            }

            public static void CreateArray(out Student[] array)
            {
                Console.Write("Enter the number of students: ");
                int size = int.Parse(Console.ReadLine());
                array = new Student[size];
            }

            // Function to accept student information
            public static void AcceptInfo(Student[] array)
            {
                for (int i = 0; i < array.Length; i++)
                {
                    Console.WriteLine($"\nEnter details for Student {i + 1}:");
                    array[i] = new Student();
                    array[i].AcceptDetails();
                }
            }

            // Function to print the student array
            public static void PrintInfo(Student[] array)
            {
                for (int i = 0; i < array.Length; i++)
                {
                    Console.WriteLine($"Student {i + 1}:");
                    array[i].PrintDetails();
                }
            }

            // Function to reverse the array
            public static void ReverseArray(Student[] original, Student[] reversed)
            {
                for (int i = 0; i < original.Length; i++)
                {
                    reversed[i] = original[original.Length - i - 1];
                }
            }

        }
    }
}
